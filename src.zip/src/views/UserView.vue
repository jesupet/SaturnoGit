<template>
  <div>
    <FavouriteTable/>
  </div>
</template>

<script>
import FavouriteTable from "../components/FavouriteTable.vue";

export default {
    name: "UserView",
    components:{
      FavouriteTable,
    }
};
</script>

<style>

</style>
